USE Obaba;

/*
   MASTER INVENTORY DECISION ENGINE (Reorder + Expiry + Overpurchase)
   - Reorder Decision (based on stock days)
   - Over-Purchase Risk (received vs demand)
   - Expiration Status (Expired, Near Expiry, Valid)
   - Supports Fresh, Frozen, Dry/Other storage
   - Converts cases to lbs using avgWeight when catchWeight = 'No'
   - Combines Fresh + Frozen + Other into TotalStockWeight

   Author: Vyron Galapin
   Date:   Current Build
*/

WITH

/* 1. Average Daily Sales (lbs) */
daily_sales AS (
    SELECT
        s.Item,
        SUM(
            CASE 
                WHEN i.catchWeight = 'Yes' THEN s.Invoiced
                ELSE s.Invoiced * i.avgWeight
            END
        ) AS TotalSalesWeight,
        COUNT(DISTINCT s.ShipDate) AS ActiveDays,
        SUM(
            CASE 
                WHEN i.catchWeight = 'Yes' THEN s.Invoiced
                ELSE s.Invoiced * i.avgWeight
            END
        ) / NULLIF(COUNT(DISTINCT s.ShipDate),0) AS AvgDailySalesWeight
    FROM sales s
    JOIN items i ON i.Item = s.Item
    GROUP BY s.Item
),

/* 2. Sales Summary (lbs) */
sales_summary AS (
    SELECT
        s.Item,
        SUM(
            CASE 
                WHEN i.catchWeight = 'Yes' THEN s.Invoiced
                ELSE s.Invoiced * i.avgWeight
            END
        ) AS SoldWeight
    FROM sales s
    JOIN items i ON i.Item = s.Item
    GROUP BY s.Item
),

/* 3. Vendor Receipts and FF Positive Moves (lbs) */
receipts AS (
    SELECT
        t.Item,
        SUM(
            CASE 
                WHEN t.RefNumber NOT LIKE '%FF%' THEN 
                    CASE WHEN i.catchWeight = 'Yes' THEN t.Quantity ELSE t.Quantity * i.avgWeight END
                WHEN t.RefNumber LIKE '%FF%' AND t.Quantity > 0 THEN 
                    CASE WHEN i.catchWeight = 'Yes' THEN t.Quantity ELSE t.Quantity * i.avgWeight END
                ELSE 0
            END
        ) AS ReceivedWeight
    FROM transfers t
    JOIN items i ON i.Item = t.Item
    GROUP BY t.Item
),

/* 4. Fresh-to-Frozen Negative Transfers (lbs) */
transfers_out AS (
    SELECT
        t.Item,
        SUM(
            CASE 
                WHEN t.RefNumber LIKE '%FF%' AND t.Quantity < 0 THEN 
                    CASE WHEN i.catchWeight = 'Yes' THEN t.Quantity ELSE t.Quantity * i.avgWeight END
                ELSE 0
            END
        ) AS TransferOutWeight
    FROM transfers t
    JOIN items i ON i.Item = t.Item
    GROUP BY t.Item
),

/* 5. Last Transfer Date (used as receiving/production date) */
last_transfer AS (
    SELECT 
        Item,
        MAX(BillDate) AS LastTransferDate
    FROM transfers
    WHERE RefNumber NOT LIKE '%FF%'
       OR (RefNumber LIKE '%FF%' AND Quantity > 0)
    GROUP BY Item
),

/* 6. Storage-Level Stock (lbs) */
stock_status AS (
    SELECT
        i.Item,
        i.storage,
        i.CategoryCode,
        i.CategoryDescription,
        i.shelfDay,

        CASE WHEN i.catchWeight = 'Yes' THEN i.onHand ELSE i.onHand * i.avgWeight END AS StartingOnHandWeight,
        COALESCE(r.ReceivedWeight,0) AS ReceivedWeight,
        COALESCE(t.TransferOutWeight,0) AS TransferOutWeight,
        COALESCE(s.SoldWeight,0) AS SoldWeight,

        CASE 
            WHEN i.storage = 'Fresh' THEN
                CASE WHEN i.catchWeight = 'Yes' THEN i.onHand ELSE i.onHand * i.avgWeight END
                + COALESCE(r.ReceivedWeight,0)
                + COALESCE(t.TransferOutWeight,0)
                - COALESCE(s.SoldWeight,0)

            WHEN i.storage = 'Frozen' THEN
                CASE WHEN i.catchWeight = 'Yes' THEN i.onHand ELSE i.onHand * i.avgWeight END
                + COALESCE(r.ReceivedWeight,0)
                - COALESCE(s.SoldWeight,0)

            ELSE
                CASE WHEN i.catchWeight = 'Yes' THEN i.onHand ELSE i.onHand * i.avgWeight END
                + COALESCE(r.ReceivedWeight,0)
                - COALESCE(s.SoldWeight,0)
        END AS OnHandWeight
    FROM items i
    LEFT JOIN receipts      r ON i.Item = r.Item
    LEFT JOIN transfers_out t ON i.Item = t.Item
    LEFT JOIN sales_summary s ON i.Item = s.Item
),

/* 7. Combine Fresh + Frozen + Dry/Other */
combined_stock AS (
    SELECT
        i.Item,
        i.CategoryDescription,

        COALESCE(f.OnHandWeight,0) AS FreshStockWeight,
        COALESCE(z.OnHandWeight,0) AS FrozenStockWeight,
        COALESCE(o.OnHandWeight,0) AS OtherStockWeight,

        COALESCE(f.OnHandWeight,0)
      + COALESCE(z.OnHandWeight,0)
      + COALESCE(o.OnHandWeight,0) AS TotalStockWeight,

        ds.AvgDailySalesWeight,
        ds.TotalSalesWeight,
        lt.LastTransferDate,
        i.shelfDay,
        i.storage
    FROM items i
    LEFT JOIN stock_status f ON f.Item = i.Item AND f.storage = 'Fresh'
    LEFT JOIN stock_status z ON z.Item = i.Item AND z.storage = 'Frozen'
    LEFT JOIN stock_status o ON o.Item = i.Item AND o.storage NOT IN ('Fresh','Frozen')
    LEFT JOIN daily_sales ds ON ds.Item = i.Item
    LEFT JOIN last_transfer lt ON lt.Item = i.Item
),

/* 8. Over-Purchase Risk */
overpurchase AS (
    SELECT
        i.Item,
        COALESCE(r.ReceivedWeight,0) AS ReceivedWeight,
        COALESCE(d.AvgDailySalesWeight,0) AS AvgDailySalesWeight,
        CASE 
            WHEN COALESCE(d.AvgDailySalesWeight,0) = 0 
                 AND COALESCE(r.ReceivedWeight,0) > 0 THEN 'High'
            WHEN COALESCE(r.ReceivedWeight,0)
                 / NULLIF(COALESCE(d.AvgDailySalesWeight,0) * i.shelfDay,0) > 1.5 THEN 'High'
            WHEN COALESCE(r.ReceivedWeight,0)
                 / NULLIF(COALESCE(d.AvgDailySalesWeight,0) * i.shelfDay,0) > 1.1 THEN 'Moderate'
            ELSE 'Low'
        END AS RiskLevel
    FROM items i
    LEFT JOIN receipts      r ON i.Item = r.Item
    LEFT JOIN daily_sales   d ON i.Item = d.Item
)

SELECT
    c.Item,
    c.CategoryDescription,

    c.FreshStockWeight  AS FreshStock_lbs,
    c.FrozenStockWeight AS FrozenStock_lbs,
    c.OtherStockWeight  AS OtherStock_lbs,
    c.TotalStockWeight  AS TotalStock_lbs,

    c.AvgDailySalesWeight AS AvgDailySales_lbs,

    ROUND(c.TotalStockWeight / NULLIF(c.AvgDailySalesWeight,0), 1) AS DaysOfStockLeft,

    CASE
		WHEN c.TotalStock_lbs < 0 THEN 'ERROR'
        WHEN c.AvgDailySalesWeight = 0 THEN 'No Sales Data'
        WHEN (c.FrozenStockWeight / NULLIF(c.AvgDailySalesWeight,0)) <= 5
             AND c.FreshStockWeight > 0 THEN 'No Need to Order (Fresh Available)'
        WHEN c.TotalStockWeight / NULLIF(c.AvgDailySalesWeight,0) <= 5 THEN 'ORDER NOW'
        WHEN c.TotalStockWeight / NULLIF(c.AvgDailySalesWeight,0) BETWEEN 6 AND 15 THEN 'Monitor Stock'
        ELSE 'Stock Sufficient'
    END AS ReorderDecision,

    c.LastTransferDate,
    DATE_ADD(c.LastTransferDate, INTERVAL c.shelfDay DAY) AS ExpiryDate,

    CASE
        WHEN c.TotalStockWeight <= 0 THEN 'Sold Out'
        WHEN DATE_ADD(c.LastTransferDate, INTERVAL c.shelfDay DAY) < CURDATE()
            THEN 'Expired (Still in Stock)'
        WHEN DATE_ADD(c.LastTransferDate, INTERVAL c.shelfDay DAY)
             BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 10 DAY)
            THEN 'Near Expiry'
        ELSE 'Valid'
    END AS ExpiryStatus,

    o.RiskLevel AS PurchaseRisk

FROM combined_stock c
LEFT JOIN overpurchase o ON o.Item = c.Item

ORDER BY 
    ReorderDecision,
    ExpiryStatus,
    PurchaseRisk DESC,
    TotalStock_lbs DESC;
