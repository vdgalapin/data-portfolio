/* 
   INVENTORY PERFORMANCE ANALYSIS (ABC + FSN)

   Purpose:
   - Categorize items by sales performance (ABC Analysis)
   - Classify items by movement frequency (FSN Analysis)
   - Combine inventory movement metrics into a ranked report
   - Fully weighted for Catch-Weight items (meat, seafood)
        * avgWeight = 1 → quantity already in pounds (CW)
        * avgWeight > 1 → quantity in cases → convert to weight

   Author: Vyron Galapin
   Date:   Current Build
*/

WITH 

/* 1. TOTAL SALES SUMMARY
   Calculate total quantity sold (in weight) and number of unique orders.
   Catch Weight:
     - If avgWeight = 1 → invoiced is weight
     - Else → invoiced cases × avgWeight 
*/
sales_total AS (
    SELECT
        s.item,
        SUM(
            CASE 
                WHEN i.catchWeight = 'Yes' THEN s.Invoiced
                ELSE s.Invoiced * i.avgWeight
            END
        ) AS total_sold,
        COUNT(DISTINCT s.OrderNumber) AS transaction_count
    FROM sales s
    JOIN items i ON s.item = i.item
    GROUP BY s.item
),

/* 2. MAX AND MIN TRANSACTION COUNTS
   Used for FSN scaling (Fast / Slow / Non-moving)
*/
stats AS (
  SELECT
        MIN(transaction_count) AS minimum_transaction_count,
        MAX(transaction_count) AS maximum_transaction_count
  FROM sales_total
),

/* 3. TOTAL RECEIPTS (Vendor Only)
   Excludes FF transfers.
   Convert cases to weight using avgWeight.
*/
receipts_total AS (
    SELECT
        t.item,
        SUM(
            CASE
                WHEN i.catchWeight = 'Yes' THEN t.Quantity
                ELSE t.Quantity * i.avgWeight
            END
        ) AS receipts_qty
    FROM transfers t
    JOIN items i ON t.item = i.item
    WHERE t.RefNumber NOT LIKE 'FF%'
    GROUP BY t.item
),

/* 4. FRESH-TO-FROZEN TRANSFERS
   ff_out = Fresh to Frozen (negative quantity)
   ff_in  = Frozen receiving FF (positive quantity)
   Both converted to weight.
*/
ff_total AS (
    SELECT
        t.item,

        SUM(
            CASE WHEN t.RefNumber LIKE 'FF%' AND t.Quantity < 0 THEN
                CASE WHEN i.catchWeight = 'Yes' THEN -t.Quantity
                     ELSE -t.Quantity * i.avgWeight
                END
            ELSE 0 END
        ) AS ff_out,

        SUM(
            CASE WHEN t.RefNumber LIKE 'FF%' AND t.Quantity > 0 THEN
                CASE WHEN i.catchWeight = 'Yes' THEN t.Quantity
                     ELSE t.Quantity * i.avgWeight
                END
            ELSE 0 END
        ) AS ff_in

    FROM transfers t
    JOIN items i ON t.item = i.item
    GROUP BY t.item
),

/* 5. MOVEMENT SUMMARY
   Combine:
     - starting inventory (converted to weight)
     - receipts
     - sales
     - ff_out / ff_in
   Compute ending inventory in weight.
*/
movement AS (
    SELECT
        i.item,
        i.storage,
        i.shelfDay,

        COALESCE(r.receipts_qty, 0) AS receipts,
        COALESCE(s.total_sold, 0) AS sales,
        COALESCE(f.ff_out, 0) AS transferOut,
        COALESCE(f.ff_in, 0) AS transferIn,
        COALESCE(s.transaction_count, 0) AS transaction_count,

        CASE 
            WHEN i.avgWeight = 1 THEN i.onHand
            ELSE i.onHand * i.avgWeight
        END AS starting_onHand,

        GREATEST(
            CASE 
                WHEN i.catchWeight = 'Yes' THEN i.onHand
                ELSE i.onHand * i.avgWeight
            END
            + COALESCE(r.receipts_qty, 0)
            - COALESCE(s.total_sold, 0)
            - COALESCE(f.ff_out, 0)
            + COALESCE(f.ff_in, 0),
        0) AS ending_onHand

    FROM items i
    LEFT JOIN receipts_total r ON i.item = r.item
    LEFT JOIN sales_total s ON i.item = s.item
    LEFT JOIN ff_total f ON i.item = f.item
),

/* 6. ABC ANALYSIS PREPARATION
   ABC Logic:
     - A: first 70% of cumulative sales
     - B: next 20%
     - C: last 10%
*/
ABS_ANALYSIS AS (
    SELECT
        item,
        storage,
        shelfDay,
        receipts,
        sales,
        transferOut,
        transferIn,
        ending_onHand,
        transaction_count,

        SUM(sales) OVER (ORDER BY sales DESC) AS cumulative_sales,
        SUM(sales) OVER () AS total_sales
    FROM movement
)

-- 7. FINAL REPORT (ABC + FSN)
SELECT
    item,
    storage,
    shelfDay,
    receipts,
    sales,
    transferOut,
    transferIn,
    ending_onHand,
    transaction_count,

    ROUND((cumulative_sales / total_sales) * 100, 2) AS cum_percent,

    CASE
      WHEN (cumulative_sales / total_sales) * 100 <= 70 THEN 'A'
      WHEN (cumulative_sales / total_sales) * 100 <= 90 THEN 'B'
      ELSE 'C'
    END AS abc_class,

    CASE
        WHEN (transaction_count - minimum_transaction_count) 
             / NULLIF(maximum_transaction_count - minimum_transaction_count, 0) >= 0.67 THEN 'F'
        WHEN (transaction_count - minimum_transaction_count) 
             / NULLIF(maximum_transaction_count - minimum_transaction_count, 0) >= 0.33 THEN 'S'
        ELSE 'N'
    END AS fsn_class

FROM ABS_ANALYSIS, stats

ORDER BY
    FIELD(
      CONCAT(
        CASE
          WHEN (cumulative_sales / total_sales) * 100 <= 70 THEN 'A'
          WHEN (cumulative_sales / total_sales) * 100 <= 90 THEN 'B'
          ELSE 'C'
        END,
        '-',
        CASE
            WHEN (transaction_count - minimum_transaction_count) 
                 / NULLIF(maximum_transaction_count - minimum_transaction_count, 0) >= 0.67 THEN 'F'
            WHEN (transaction_count - minimum_transaction_count) 
                 / NULLIF(maximum_transaction_count - minimum_transaction_count, 0) >= 0.33 THEN 'S'
            ELSE 'N'
        END
      ),
        'A-F', 'B-F', 'A-S', 'C-F', 'B-S', 'A-N', 'B-N', 'C-S', 'C-N'
    ),
    ending_onHand DESC;
    

